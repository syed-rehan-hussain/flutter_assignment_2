import 'package:flutter/material.dart';

void main() {
  runApp(LoginForm());
}

class LoginForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              TextFormField(
                decoration: InputDecoration(
                    icon: Icon(Icons.people),
                    labelText: 'Username',
                    hintText: 'Enter Username'),
              ),
              TextFormField(
                decoration: InputDecoration(
                  icon: Icon(Icons.remove_red_eye),
                  labelText: 'Password',
                  hintText: 'Enter Password',
                ),
                obscureText: true,
              ),
              SizedBox(
                height: 10.0,
              ),
              ElevatedButton(onPressed: () {}, child: Text('Sign in'))
            ]),
          ),
        ));
  }
}
